const MAX_SIZE = 25 * 1024 * 1024;

const generateId = () => {
  return Date.now().toString(36) + Math.random().toString(36).substring(2, 7);
};

const formatSize = (bytes) => {
  const sizes = ['字节', 'KB', 'MB'];
  if (bytes === 0) return '0 字节';
  const i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)));
  return Math.round(bytes / Math.pow(1024, i), 2) + ' ' + sizes[i];
};

const handleError = (error, status = 500) => {
  console.error('Error:', error);
  return new Response(
    JSON.stringify({ error: error.message || '服务器错误' }), 
    { 
      status, 
      headers: { 'Content-Type': 'application/json' }
    }
  );
};

async function handleAdminLogin(request, env) {
  try {
    const { username, password } = await request.json();
    
    if (username === env.ADMIN_USERNAME && password === env.ADMIN_PASSWORD) {
      const response = new Response(JSON.stringify({ success: true, message: '登录成功', isAdmin: true }));
      response.headers.set('Set-Cookie', 'isAdmin=true; Path=/; HttpOnly; Secure; SameSite=Strict');
      return response;
    } else {
      return new Response(JSON.stringify({ success: false, message: '用户名或密码错误' }), { status: 401 });
    }
  } catch (error) {
    return handleError(error);
  }
}

async function handleUpload(request, env) {
  try {
    const cookies = request.headers.get('Cookie') || '';
    if (!cookies.includes('isAdmin=true')) {
      return handleError(new Error('请先登录'), 401);
    }

    const formData = await request.formData();
    const file = formData.get('file');

    if (!file) {
      return handleError(new Error('请选择文件'), 400);
    }

    if (file.size > MAX_SIZE) {
      return handleError(new Error(`文件过大。最大支持 ${formatSize(MAX_SIZE)}`), 400);
    }

    const fileId = generateId();
    const arrayBuffer = await file.arrayBuffer();
    
    await env.FILE_STORAGE.put(`file:${fileId}:content`, arrayBuffer);
    await env.FILE_STORAGE.put(`file:${fileId}:type`, file.type || 'application/octet-stream');
    await env.FILE_STORAGE.put(`file:${fileId}:name`, file.name);
    await env.FILE_STORAGE.put(`file:${fileId}:size`, file.size.toString());
    await env.FILE_STORAGE.put(`file:${fileId}:time`, new Date().toISOString());

    let files = [];
    const filesListStr = await env.FILE_STORAGE.get('files:list');
    if (filesListStr) {
      try {
        files = JSON.parse(filesListStr);
      } catch (e) {
        console.error('解析文件列表失败:', e);
      }
    }

    files.unshift({
      id: fileId,
      name: file.name,
      size: formatSize(file.size),
      time: new Date().toISOString(),
      viewUrl: `/view/${fileId}`,
      downloadUrl: `/download/${fileId}`
    });

    await env.FILE_STORAGE.put('files:list', JSON.stringify(files));

    return new Response(JSON.stringify({
      success: true,
      viewUrl: `/view/${fileId}`,
      downloadUrl: `/download/${fileId}`,
      files
    }), { headers: { 'Content-Type': 'application/json' } });

  } catch (error) {
    return handleError(error);
  }
}

async function handleCreateFile(request, env) {
  try {
    const cookies = request.headers.get('Cookie') || '';
    if (!cookies.includes('isAdmin=true')) {
      return handleError(new Error('请先登录'), 401);
    }

    const { fileName, content } = await request.json();
    
    if (!fileName || !content) {
      return handleError(new Error('文件名和内容不能为空'), 400);
    }

    const fileId = generateId();
    const encoder = new TextEncoder();
    const arrayBuffer = encoder.encode(content);
    
    if (arrayBuffer.length > MAX_SIZE) {
      return handleError(new Error(`文件过大。最大支持 ${formatSize(MAX_SIZE)}`), 400);
    }

    await env.FILE_STORAGE.put(`file:${fileId}:content`, arrayBuffer);
    await env.FILE_STORAGE.put(`file:${fileId}:type`, 'text/plain');
    await env.FILE_STORAGE.put(`file:${fileId}:name`, fileName);
    await env.FILE_STORAGE.put(`file:${fileId}:size`, arrayBuffer.length.toString());
    await env.FILE_STORAGE.put(`file:${fileId}:time`, new Date().toISOString());

    let files = [];
    const filesListStr = await env.FILE_STORAGE.get('files:list');
    if (filesListStr) {
      try {
        files = JSON.parse(filesListStr);
      } catch (e) {
        console.error('解析文件列表失败:', e);
      }
    }

    files.unshift({
      id: fileId,
      name: fileName,
      size: formatSize(arrayBuffer.length),
      time: new Date().toISOString(),
      viewUrl: `/view/${fileId}`,
      downloadUrl: `/download/${fileId}`
    });

    await env.FILE_STORAGE.put('files:list', JSON.stringify(files));

    return new Response(JSON.stringify({
      success: true,
      viewUrl: `/view/${fileId}`,
      downloadUrl: `/download/${fileId}`,
      files
    }), { headers: { 'Content-Type': 'application/json' } });

  } catch (error) {
    return handleError(error);
  }
}

async function handleDelete(request, env) {
  try {
    const cookies = request.headers.get('Cookie') || '';
    if (!cookies.includes('isAdmin=true')) {
      return handleError(new Error('请先登录'), 401);
    }

    const { id } = await request.json();
    
    await env.FILE_STORAGE.delete(`file:${id}:content`);
    await env.FILE_STORAGE.delete(`file:${id}:type`);
    await env.FILE_STORAGE.delete(`file:${id}:name`);
    await env.FILE_STORAGE.delete(`file:${id}:size`);
    await env.FILE_STORAGE.delete(`file:${id}:time`);

    let files = [];
    const filesListStr = await env.FILE_STORAGE.get('files:list');
    if (filesListStr) {
      try {
        files = JSON.parse(filesListStr);
        files = files.filter(item => item.id !== id);
        await env.FILE_STORAGE.put('files:list', JSON.stringify(files));
      } catch (e) {
        console.error('更新文件列表失败:', e);
      }
    }

    return new Response(JSON.stringify({ success: true, files }), { 
      headers: { 'Content-Type': 'application/json' }
    });
  } catch (error) {
    return handleError(error);
  }
}

async function handleView(request, env, id) {
  try {
    const content = await env.FILE_STORAGE.get(`file:${id}:content`, { type: 'arrayBuffer' });
    const contentType = await env.FILE_STORAGE.get(`file:${id}:type`);
    const fileName = await env.FILE_STORAGE.get(`file:${id}:name`);

    if (!content) {
      return new Response('文件未找到', { status: 404 });
    }

    return new Response(content, {
      headers: {
        'Content-Type': contentType || 'application/octet-stream',
        'Content-Disposition': `inline; filename*=UTF-8''${encodeURIComponent(fileName)}`,
        'Cache-Control': 'no-cache',
        'Accept-Ranges': 'bytes'
      }
    });
  } catch (error) {
    return handleError(error);
  }
}

async function handleDownload(request, env, id) {
  try {
    const content = await env.FILE_STORAGE.get(`file:${id}:content`, { type: 'arrayBuffer' });
    const contentType = await env.FILE_STORAGE.get(`file:${id}:type`);
    const fileName = await env.FILE_STORAGE.get(`file:${id}:name`);
    const fileSize = await env.FILE_STORAGE.get(`file:${id}:size`);

    if (!content) {
      return new Response('文件未找到', { status: 404 });
    }

    return new Response(content, {
      headers: {
        'Content-Type': 'application/octet-stream',
        'Content-Disposition': `attachment; filename*=UTF-8''${encodeURIComponent(fileName)}`,
        'Content-Length': fileSize,
        'Cache-Control': 'no-cache',
        'Accept-Ranges': 'bytes'
      }
    });
  } catch (error) {
    return handleError(error);
  }
}

async function handleFiles(request, env) {
  try {
    const files = await env.FILE_STORAGE.get('files:list');
    return new Response(files || '[]', {
      headers: { 'Content-Type': 'application/json' }
    });
  } catch (error) {
    return handleError(error);
  }
}

async function handleSearch(request, env) {
  try {
    const { searchTerm } = await request.json();
    const filesListStr = await env.FILE_STORAGE.get('files:list');
    let files = [];
    
    if (filesListStr) {
      try {
        files = JSON.parse(filesListStr);
      } catch (e) {
        console.error('解析文件列表失败:', e);
      }
    }

    if (searchTerm) {
      const searchTermLower = searchTerm.toLowerCase();
      files = files.filter(file => 
        file.name.toLowerCase().includes(searchTermLower)
      );
    }

    return new Response(JSON.stringify(files), {
      headers: { 'Content-Type': 'application/json' }
    });
  } catch (error) {
    return handleError(error);
  }
}

const html = `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">
  <title>文件分享</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { 
      font-family: system-ui, -apple-system, sans-serif;
      background: #f5f5f5;
      line-height: 1.5;
      min-height: 100vh;
    }
    .container {
      max-width: 800px;
      margin: 0 auto;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      justify-content: center;
      padding: 20px;
    }
    .card {
      background: white;
      border-radius: 8px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
      padding: 20px;
      margin-bottom: 20px;
    }
    .title {
      font-size: 24px;
      font-weight: bold;
      margin-bottom: 16px;
    }
    #drop {
      border: 2px dashed #ccc;
      border-radius: 8px;
      padding: 32px;
      text-align: center;
      cursor: pointer;
      transition: all 0.2s;
    }
    #drop:hover, #drop.dragover {
      border-color: #2563eb;
      background: #f0f7ff;
    }
    .hint {
      font-size: 14px;
      color: #666;
      margin-top: 8px;
    }
    .file-item {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 12px;
      border-bottom: 1px solid #eee;
    }
    .file-item:last-child {
      border-bottom: none;
    }
    .file-info {
      flex: 1;
      min-width: 0;
      padding-right: 12px;
    }
    .file-name {
      font-weight: 500;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .file-meta {
      font-size: 12px;
      color: #666;
    }
    .btn-group {
      display: flex;
      gap: 8px;
      flex-shrink: 0;
    }
    .btn {
      background: #2563eb;
      color: white;
      padding: 6px 12px;
      border-radius: 4px;
      text-decoration: none;
      font-size: 14px;
      cursor: pointer;
      border: none;
      transition: background 0.2s;
      white-space: nowrap;
    }
    .btn:hover {
      background: #1d4ed8;
    }
    .btn.copy {
      background: #059669;
    }
    .btn.copy:hover {
      background: #047857;
    }
    .btn.delete {
      background: #ef4444;
    }
    .btn.delete:hover {
      background: #dc2626;
    }
    .btn.download {
      background: #6366f1;
    }
    .btn.download:hover {
      background: #4f46e5;
    }
    #toast {
      position: fixed;
      bottom: 20px;
      right: 20px;
      padding: 12px 24px;
      border-radius: 4px;
      color: white;
      display: none;
      animation: slideIn 0.3s ease;
      z-index: 1000;
      box-shadow: 0 2px 8px rgba(0,0,0,0.2);
    }
    @keyframes slideIn {
      from { transform: translateX(100%); opacity: 0; }
      to { transform: translateX(0); opacity: 1; }
    }
    .empty-state {
      text-align: center;
      padding: 32px;
      color: #666;
    }
    .login-form {
      display: none;
      flex-direction: column;
      gap: 16px;
      max-width: 400px;
      margin: 0 auto;
      width: 100%;
    }
    .login-form input {
      padding: 12px;
      border: 1px solid #ddd;
      border-radius: 6px;
      font-size: 16px;
      transition: border-color 0.3s;
    }
    .login-form input:focus {
      outline: none;
      border-color: #2563eb;
    }
    .login-form .btn {
      padding: 12px;
      font-size: 16px;
      font-weight: 500;
    }
    .login-form .title {
      text-align: center;
      color: #1f2937;
      font-size: 28px;
      margin-bottom: 24px;
    }
    .search-box {
      margin-bottom: 16px;
    }
    .search-box input {
      width: 100%;
      padding: 8px 12px;
      border: 1px solid #ddd;
      border-radius: 6px;
      font-size: 14px;
      transition: border-color 0.3s;
    }
    .search-box input:focus {
      outline: none;
      border-color: #2563eb;
    }
    .no-results {
      text-align: center;
      padding: 32px;
      color: #666;
    }
    .create-file-form {
      display: flex;
      flex-direction: column;
      gap: 16px;
    }
    .input-field {
      padding: 12px;
      border: 1px solid #ddd;
      border-radius: 6px;
      font-size: 14px;
      transition: border-color 0.3s;
    }
    .textarea-field {
      padding: 12px;
      border: 1px solid #ddd;
      border-radius: 6px;
      font-size: 14px;
      min-height: 200px;
      resize: vertical;
      font-family: inherit;
      transition: border-color 0.3s;
    }
    .input-field:focus,
    .textarea-field:focus {
      outline: none;
      border-color: #2563eb;
    }
    @media (max-width: 600px) {
      body { padding: 10px; }
      .card { padding: 15px; }
      .btn-group { flex-direction: column; }
      .btn { width: 100%; text-align: center; }
      .file-info { padding-right: 8px; }
      .container { padding: 16px; }
      .login-form { max-width: 100%; }
      .login-form .title { font-size: 24px; }
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="card login-form" id="login-form">
      <div class="title">管理员登录</div>
      <input type="text" id="username" placeholder="用户名" autocomplete="username">
      <input type="password" id="password" placeholder="密码" autocomplete="current-password">
      <button class="btn" id="login-button">登录</button>
    </div>

    <div class="card" id="upload-card" style="display: none;">
      <div class="title">文件分享</div>
      <div id="drop">
        <div>拖放文件或点击上传</div>
        <div class="hint">最大支持 25MB 的文件</div>
      </div>
      <input type="file" id="file" style="display:none">
    </div>

    <div class="card" id="create-file-card" style="display: none;">
      <div class="title">创建文件</div>
      <div class="create-file-form">
        <input type="text" id="new-file-name" placeholder="输入文件名" class="input-field">
        <textarea id="file-content" placeholder="输入文件内容" class="textarea-field"></textarea>
        <button class="btn" id="create-file-button">创建文件</button>
      </div>
    </div>

    <div class="card" id="files-card" style="display: none;">
      <div class="title">文件列表</div>
      <div class="search-box">
        <input type="text" id="search-input" placeholder="搜索文件...">
      </div>
      <div id="files">
        <div class="empty-state">暂无文件</div>
      </div>
    </div>
  </div>

  <div id="toast"></div>

  <script>
    let isAdmin = false;
    let allFiles = [];
    let searchTimeout = null;

    const drop = document.getElementById('drop');
    const file = document.getElementById('file');
    const toast = document.getElementById('toast');
    const loginForm = document.getElementById('login-form');
    const uploadCard = document.getElementById('upload-card');
    const createFileCard = document.getElementById('create-file-card');
    const filesCard = document.getElementById('files-card');
    const searchInput = document.getElementById('search-input');
    const createFileButton = document.getElementById('create-file-button');

    function showToast(message, type = 'success') {
      toast.textContent = message;
      toast.style.display = 'block';
      toast.style.background = type === 'success' ? '#10b981' : '#ef4444';
      setTimeout(() => {
        toast.style.display = 'none';
      }, 3000);
    }

    async function copyToClipboard(text) {
      try {
        await navigator.clipboard.writeText(window.location.origin + text);
        showToast('链接已复制到剪贴板');
      } catch (err) {
        showToast('复制链接失败', 'error');
      }
    }

    async function downloadFile(url, filename) {
      try {
        const response = await fetch(url);
        if (!response.ok) {
          throw new Error('下载失败');
        }
        
        const blob = await response.blob();
        const downloadUrl = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = downloadUrl;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        
        setTimeout(() => {
          window.URL.revokeObjectURL(downloadUrl);
          document.body.removeChild(a);
        }, 100);
      } catch (error) {
        console.error('下载错误:', error);
        showToast('下载失败: ' + error.message, 'error');
      }
    }

    async function handleFile(file) {
      if(!file) return;
    
      const data = new FormData();
      data.append('file', file, file.name);
    
      try {
        const res = await fetch('/upload', {
          method: 'POST',
          body: data
        });
    
        const json = await res.json();
        
        if(json.error) {
          showToast(json.error, 'error');
        } else {
          updateFiles(json.files);
          showToast('文件上传成功！');
        }
      } catch(err) {
        showToast('上传失败: ' + err.message, 'error');
      }
    }

    async function createFile() {
      const fileName = document.getElementById('new-file-name').value.trim();
      const content = document.getElementById('file-content').value.trim();
      
      if (!fileName) {
        showToast('请输入文件名', 'error');
        return;
      }
      
      if (!content) {
        showToast('请输入文件内容', 'error');
        return;
      }

      try {
        const res = await fetch('/create-file', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ fileName, content })
        });

        const json = await res.json();
        
        if (json.error) {
          showToast(json.error, 'error');
        } else {
          updateFiles(json.files);
          showToast('文件创建成功！');
          document.getElementById('new-file-name').value = '';
          document.getElementById('file-content').value = '';
        }
      } catch (err) {
        showToast('创建失败: ' + err.message, 'error');
      }
    }

    async function deleteFile(id) {
      try {
        const res = await fetch('/delete', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ id })
        });

        const json = await res.json();

        if (json.success) {
          updateFiles(json.files);
          showToast('文件删除成功！');
        } else {
          showToast(json.error, 'error');
        }
      } catch (err) {
        showToast('删除失败: ' + err.message, 'error');
      }
    }

    function updateFiles(items) {
      allFiles = items || [];
      filterFiles(searchInput.value);
    }

    function filterFiles(searchTerm = '') {
      const filesEl = document.getElementById('files');
      const filteredFiles = allFiles.filter(file => 
        file.name.toLowerCase().includes(searchTerm.toLowerCase())
      );
      
      if (filteredFiles.length === 0) {
        filesEl.innerHTML = '<div class="empty-state">' + 
          (searchTerm ? '没有找到匹配的文件' : '暂无文件') + 
          '</div>';
        return;
      }
      
      filesEl.innerHTML = filteredFiles.map(item => \`
        <div class="file-item">
          <div class="file-info">
            <div class="file-name">\${item.name}</div>
            <div class="file-meta">
              \${new Date(item.time).toLocaleString()} · \${item.size || ''}
            </div>
          </div>
          <div class="btn-group">
            <button class="btn copy" onclick="copyToClipboard('\${item.viewUrl}')">复制链接</button>
            <button class="btn" onclick="window.open('\${item.viewUrl}', '_blank')">查看</button>
            <button class="btn download" onclick="downloadFile('\${item.downloadUrl}', '\${item.name}')">下载</button>
            <button class="btn delete" onclick="deleteFile('\${item.id}')">删除</button>
          </div>
        </div>
      \`).join('');
    }

    async function searchFiles(searchTerm) {
      try {
        const res = await fetch('/search', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ searchTerm })
        });
        
        const files = await res.json();
        updateFiles(files);
      } catch (err) {
        console.error('搜索错误:', err);
      }
    }

    searchInput.addEventListener('input', (e) => {
      if (searchTimeout) {
        clearTimeout(searchTimeout);
      }
      searchTimeout = setTimeout(() => {
        searchFiles(e.target.value);
      }, 300);
    });

    drop.onclick = () => file.click();
    drop.ondragover = e => {
      e.preventDefault();
      drop.classList.add('dragover');
    };
    drop.ondragleave = e => {
      e.preventDefault();
      drop.classList.remove('dragover');
    };
    drop.ondrop = e => {
      e.preventDefault();
      drop.classList.remove('dragover');
      handleFile(e.dataTransfer.files[0]);
    };
    file.onchange = e => handleFile(e.target.files[0]);
    createFileButton.onclick = createFile;

    document.getElementById('login-button').onclick = async () => {
      const username = document.getElementById('username').value;
      const password = document.getElementById('password').value;

      try {
        const res = await fetch('/admin-login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ username, password })
        });

        const json = await res.json();

        if (json.success) {
          isAdmin = true;
          showToast('登录成功');
          loginForm.style.display = 'none';
          uploadCard.style.display = 'block';
          createFileCard.style.display = 'block';
          filesCard.style.display = 'block';
          fetch('/files').then(r => r.json()).then(updateFiles);
        } else {
          showToast(json.message, 'error');
        }
      } catch (err) {
        showToast('登录失败: ' + err.message, 'error');
      }
    };

    document.getElementById('password').addEventListener('keypress', function(e) {
      if (e.key === 'Enter') {
        document.getElementById('login-button').click();
      }
    });

    if (!isAdmin) {
      loginForm.style.display = 'flex';
      uploadCard.style.display = 'none';
      createFileCard.style.display = 'none';
      filesCard.style.display = 'none';
    }
  </script>
</body>
</html>`;

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const path = url.pathname;

    if (request.method === 'OPTIONS') {
      return new Response(null, {
        headers: {
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
          'Access-Control-Allow-Headers': 'Content-Type'
        }
      });
    }

    try {
      if (path === '/' || path === '/index.html') {
        return new Response(html, {
          headers: { 'Content-Type': 'text/html;charset=utf-8' }
        });
      }

      if (path === '/admin-login' && request.method === 'POST') {
        return await handleAdminLogin(request, env);
      }

      if (path === '/upload' && request.method === 'POST') {
        return await handleUpload(request, env);
      }

      if (path === '/create-file' && request.method === 'POST') {
        return await handleCreateFile(request, env);
      }

      if (path === '/delete' && request.method === 'POST') {
        return await handleDelete(request, env);
      }

      if (path === '/files') {
        return await handleFiles(request, env);
      }

      if (path === '/search' && request.method === 'POST') {
        return await handleSearch(request, env);
      }

      if (path.startsWith('/view/')) {
        return await handleView(request, env, decodeURIComponent(path.slice(6)));
      }

      if (path.startsWith('/download/')) {
        return await handleDownload(request, env, decodeURIComponent(path.slice(10)));
      }

      return new Response('Not Found', { status: 404 });
    } catch (error) {
      return handleError(error);
    }
  }
};
